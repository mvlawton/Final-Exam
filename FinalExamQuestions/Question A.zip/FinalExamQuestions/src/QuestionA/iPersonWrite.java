package QuestionA;

import java.util.Date;

public interface iPersonWrite {

	void setFirstName(String FirstName);

	void setMiddleName(String MiddleName);

	void setLastName(String LastName);

	void setDOB(Date DOB);

	void setAddress(String newAddress);

	void setPhone(String newPhone_number);

	void setEmail(String newEmail);

}