package QuestionA;

import java.util.Date;

public interface iPersonRead {

	String getFirstName();

	String getMiddleName();

	String getLastName();

	Date getDOB();

	String getAddress();

	String getPhone();

	String getEmail();

}